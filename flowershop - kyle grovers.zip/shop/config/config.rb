module FlowerShop
  PRICELIST_PATH = "data/pricelist.csv"
end
